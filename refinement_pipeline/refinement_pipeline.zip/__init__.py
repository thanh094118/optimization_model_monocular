"""Single WHAM optimization pipeline."""
